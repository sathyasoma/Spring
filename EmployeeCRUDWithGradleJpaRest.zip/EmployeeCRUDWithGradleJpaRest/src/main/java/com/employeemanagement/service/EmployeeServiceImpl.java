package com.employeemanagement.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.employeemanagement.dao.EmployeeDao;
import com.employeemanagement.entity.Employee;

@Service("employeeService")
public class EmployeeServiceImpl implements EmployeeService {
	@Autowired
	private EmployeeDao dao;

	@Override
	public Employee addEmployee(Employee emp) {
		//dao.saveAll(List)
		return dao.save(emp);// persist()
		
	}

	@Override
	public Employee updateEmployee(Employee emp) {
		return dao.save(emp);
	}

	@Override
	public void removeEmployee(int empId) {
		dao.deleteById(empId);
	}

	@Override
	public Optional<Employee> findEmployeeById(int eid) {
		// no need of transaction, as it's an read operation
		Optional<Employee> emp = dao.findById(eid);// 124
		return emp;
	}

	@Override
	public List<Employee> findEmployeeByName(String ename) {

		return dao.findByEname(ename);
	}

	@Override
	public List<Employee> listEmployee() {

		List<Employee> l1 = dao.findAll();
		return l1;
	}

	@Override
	public List<Employee> getAllInBetween(int initialSal, int salary) {

		return dao.getAllInBetween(initialSal, salary);
	}
}