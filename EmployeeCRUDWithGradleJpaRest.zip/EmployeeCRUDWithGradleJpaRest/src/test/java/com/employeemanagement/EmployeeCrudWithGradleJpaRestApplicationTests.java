package com.employeemanagement;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.employeemanagement.dao.EmployeeDao;
import com.employeemanagement.entity.Employee;
import com.employeemanagement.service.EmployeeService;

@SpringBootTest
class EmployeeCrudWithGradleJpaRestApplicationTests {
	@Autowired
	EmployeeService service;//mockito
	@MockBean
	EmployeeDao dao;

	@Test
	public void testAddEmployee() {
		Employee emp = new Employee("aman", 100000, "delhi");
		when(dao.save(emp)).thenReturn(emp);
		Employee emp1 = service.addEmployee(emp);
		assertEquals("aman",emp1.getEname());
	}
	@Test
	public void testUpdateEmployee() {
		Employee employee = new Employee("aman", 100000, "delhi");
		Employee emp1 = service.addEmployee(employee);
		Employee emp = new Employee(1,"amankumar", 200000, "hyd");
		Employee employee1 = service.updateEmployee(emp);
		assertEquals("aman",employee1.getEname());
	}
}
