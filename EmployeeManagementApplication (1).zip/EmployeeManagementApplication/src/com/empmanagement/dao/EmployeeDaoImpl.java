package com.empmanagement.dao;

import java.util.HashMap;
import java.util.Map;

import com.empmanagement.model.Employee;
//@Repository is equals to @component
public class EmployeeDaoImpl implements IEmployeeDao{
	int key=1000;
	String name;
	HashMap<Integer, Employee> employees=new HashMap();
	@Override
	public int addEmployee(Employee employee) {
		employees.put(++key, employee);
		return key;
	}

	@Override
	public Employee updateEmployee(Employee employee) {
		employees.put(employee.getEmpId(), employee);
		return employees.get(employee.getEmpId());
	}

	@Override
	public void deleteEmployee(int employeeId) {
		employees.remove(employeeId);
	}

	@Override
	public Employee getEmployee(int employeeId) {
	
		return employees.get(employeeId);
	}

	@Override
	public Map<Integer, Employee> getAllEmployee() {

		return employees;
	}

}
