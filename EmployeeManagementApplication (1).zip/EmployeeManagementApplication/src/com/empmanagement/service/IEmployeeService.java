package com.empmanagement.service;

import java.util.Map;

import com.empmanagement.exceptions.EmployeeIdNotFoundException;
import com.empmanagement.model.Employee;

public interface IEmployeeService {
	int addEmployee(Employee employee);

	Employee updateEmployee(Employee employee);

	void deleteEmployee(int employeeId) throws EmployeeIdNotFoundException;

	Employee getEmployee(int employeeId);

	Map<Integer,Employee> getAllEmployee();
}
