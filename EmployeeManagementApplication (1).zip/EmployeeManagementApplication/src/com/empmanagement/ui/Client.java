package com.empmanagement.ui;

import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

import com.empmanagement.exceptions.EmployeeIdNotFoundException;
import com.empmanagement.model.Employee;
import com.empmanagement.service.EmployeeServiceImpl;

public class Client {

	public static void main(String[] args) {
		//@Autowired
		EmployeeServiceImpl service = new EmployeeServiceImpl();
		Scanner scan = new Scanner(System.in);
		String empName = null;
		int empId = 0;
		int empSalary = 0;
		String empAddress = null;
		while(true) {
		System.out.println("**************Employee Management Application**********");
		System.out.println("1.Add Employee");
		System.out.println("2.Update Employee");
		System.out.println("3.Delete Employee");
		System.out.println("4.Get Employee");
		System.out.println("5.Get All Employee");

		int option = scan.nextInt();

		switch (option) {
		case 1:
			System.out.println("Enter Info To Add Employee");
			System.out.println("enter emp name :");
			empName = scan.next();
			System.out.println("enter emp Salary :");
			empSalary = scan.nextInt();
			System.out.println("enter emp address :");
			empAddress = scan.next();
			Employee employee = new Employee(0, empName, empSalary, empAddress);
			empId = service.addEmployee(employee);
			System.out.println("Employee Added Successfully with id :" + empId);
			break;
		case 2:
			System.out.println("Enter Info To Update Employee");
			System.out.println("enter emp id :");
			empId = scan.nextInt();
			System.out.println("enter emp name :");
			empName = scan.next();
			System.out.println("enter emp Salary :");
			empSalary = scan.nextInt();
			System.out.println("enter emp address :");
			empAddress = scan.next();
			Employee updateEmployee = new Employee(empId, empName, empSalary, empAddress);
			Employee updatedEmployee = service.updateEmployee(updateEmployee);
			System.out.println("Employee updated Successfully with id :" + updatedEmployee);
			break;
		case 3:
			System.out.println("enter emp id :");
			empId = scan.nextInt();
			try {
				service.deleteEmployee(empId);
				System.out.println("Deleted Succesfully");
			} catch (EmployeeIdNotFoundException e) {
			
				System.out.println("Empid not found to delete ...");
			}
			
			break;
		case 4:
			System.out.println("enter emp id :");
			empId = scan.nextInt();
			Employee employee1 = service.getEmployee(empId);
			System.out.println(employee1);
			break;
		case 5:
			Map<Integer, Employee> employees = service.getAllEmployee();// entry
//			Set<Entry<Integer,Employee>>emps=employees.entrySet();
//			Iterator<Entry<Integer,Employee>> itr=emps.iterator();
//			while(itr.hasNext())
//			{
//				Entry<Integer,Employee> entry=itr.next();
//				System.out.println(entry.getKey()+" "+entry.getValue());
//			}
			Set<Integer> keys = employees.keySet();
			Iterator<Integer> itr = keys.iterator();
			while(itr.hasNext())
				{
					int key=itr.next();
					System.out.println(key+" "+employees.get(key));
				}
			break;
		default:
			System.out.println("Thank you for using Application");
			System.exit(0);

			break;
		}}

	}

}
